/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication98;

import java.util.Scanner;

/**
 *
 * @author Duc Nguyen
 */
public class Test {
    public static void main (String[] args)
    {
        Project newgame = new Project();
        Scanner input = new Scanner(System.in);
        System.out.printf("Computer vs Computer press 1 | Two players press 2| Player versus Computer press 3: ");
        int menu = input.nextInt();
        System.out.printf("Enter number a row or column for NxN board: ");
        int num = input.nextInt();        
        newgame.game(menu,num);
    }
}
