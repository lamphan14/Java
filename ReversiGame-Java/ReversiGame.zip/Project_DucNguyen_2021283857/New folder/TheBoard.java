/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication98;
/**
 *
 * @author Duc Nguyen
 */
public class TheBoard {
    public void theBoard(char[][] board, int n)/*Initialize the board*/  
    {
        for (int y = 0; y < n+2; y++) /*y as column*/
        {
            for (int x = 0; x < n+2; x++) /*x as row*/
            {
                board[y][x]= '-'; /* Fill the board with -*/
            }
        }
        /*Initialize the given disc*/ 
        board[n/2][n/2] = 'W';
        board[n/2][n/2+1] = 'B';
        board[n/2+1][n/2] = 'B';
        board[n/2+1][n/2+1] = 'W';
    }
    public void updatedBoard(char[][] board,int n) /*Draw the board*/ 
    {
        for (int y = 1; y < n+1; y++)
        {
            for(int x = 1; x < n+1; x++)
            {
                System.out.print(board[y][x]);
            }
            System.out.println();
        }
        displayScore(board,n);
    }
    public static void displayScore(char[][]board, int n) /*Calculate and print the score for two players*/ 
    {
        int scoreB = 0;/*set initial score for black to 0*/ 
        int scoreW = 0;/*set the initial score for white to 0*/
        /*Check the score by comparing every element in the 2D array board*/ 
        for (int y = 1; y < n+1; y++)
        {
            for (int x = 1; x < n+1; x++)
            {
                scoreB+= board[y][x] == 'B' ? 1 : 0;/*Calculate total black discs in the board*/ 
                scoreW+= board[y][x] == 'W' ? 1 : 0;/*Calculate total black discs in the board*/ 
            }
        }
        System.out.println("Score: Black: "+scoreB +", White: "+scoreW);/*print the score*/
    }
}